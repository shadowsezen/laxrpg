﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaxRPG
{
    class Program
    {
        static void Main(string[] args)
        {
            int playerClass;

            Console.WriteLine("Welcome to LaxRPG." + Environment.NewLine + "It's a strange new world, with monsters to fight and quests to complete." + Environment.NewLine + "Can you save the day?" + Environment.NewLine);

            Console.WriteLine("To begin, please choose your class:");
            Console.WriteLine("1. Paladin");
            Console.WriteLine("2. Mage");
            Console.WriteLine("3. Ranger");
            Console.WriteLine("4. Rogue");

            string playerClassStr = Console.ReadLine();

            bool resolveClass = int.TryParse(playerClassStr, out playerClass);

            if(resolveClass == false)
            {
                Console.WriteLine("The value entered was not a number.");
            }

            Console.ReadLine();

        }
    }
}
