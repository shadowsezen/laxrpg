﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaxRPG
{
    class Battle
    {
        public int MonsterHealth()
        {
            return 20;
        }

        public void MonsterFight(int Dmg, int Health)
        {
            int playerDmg = Dmg;
            int playerHP = Health;

            Console.WriteLine();
            Console.WriteLine("A monster appears!  It has 20 HP.");
            int monsterHP = 20;

            Console.WriteLine("You attack it, but it fights back!");

            monsterHP -= playerDmg;

            Console.WriteLine("It has {0} health remaining.  You have {1} health remaining.", monsterHP, playerHP);

            while (monsterHP > 0 && playerHP > 0)
            {
                monsterHP -= playerDmg;
                playerHP--;

                Console.WriteLine("You attack it again!  It fights back again!");

                if (playerHP <= 0)
                {
                    Console.WriteLine("You have 0 health.  You've died :(");
                    Console.ReadLine();
                    return;
                }

                if (monsterHP >= 0)
                {
                    Console.WriteLine("It has {0} health remaining. You have {1} health remaining.", monsterHP, playerHP);
                }
                else if (monsterHP < 0)
                {
                    Console.WriteLine("It has 0 health remaining!");
                }
            }
        }
    }
}
