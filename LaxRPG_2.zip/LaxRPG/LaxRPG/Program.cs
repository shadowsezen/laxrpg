﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaxRPG
{
    class Program
    {
        static void Main(string[] args)
        {
            int playerClass;
            int playerHP;
            int playerMaxHP;
            int playerDmg = 0;
            int playerG = 0;
            int encounterMob = 0;


            Random rnd = new Random();

            Console.WriteLine("Welcome to LaxRPG." + Environment.NewLine + "It's a strange new world, with monsters to fight and quests to complete." + Environment.NewLine + "Can you save the day?" + Environment.NewLine);

            Console.WriteLine("To begin, please choose your class:");
            Console.WriteLine("1. Paladin");
            Console.WriteLine("2. Mage");
            Console.WriteLine("3. Ranger");
            Console.WriteLine("4. Rogue");

            string playerClassStr = Console.ReadLine();

            //try to resolve the entered value into one of the 4 class options
            bool resolveClass = int.TryParse(playerClassStr, out playerClass);

            //if you entered something that wasn't a number...
            if(resolveClass == false)
            {
                Console.WriteLine("The value entered was not a number.");
                Console.ReadLine();
                return;
            }

            //set up basic player stats
            switch(playerClass)
            {
                case 1:
                    playerHP = 10;
                    playerMaxHP = 10;
                    playerDmg = 10;
                    break;
                case 2:
                    playerHP = 7;
                    playerMaxHP = 7;
                    playerDmg = 13;
                    break;
                case 3:
                    playerHP = 9;
                    playerMaxHP = 9;
                    playerDmg = 11;
                    break;
                case 4:
                    playerHP = 8;
                    playerMaxHP = 8;
                    playerDmg = 12;
                    break;
                default:
                    playerDmg = 1;
                    playerMaxHP = 1;
                    playerHP = 1;
                    break;
            }

            Console.WriteLine();

            //monster fight sequence
            Console.WriteLine("A monster appears!  It has 20 HP.");
            int monsterHP = 20;

            Console.WriteLine("You attack it, but it fights back!");

            monsterHP -= playerDmg;
            playerHP -= 3;

            Console.WriteLine("It has {0} health remaining.  You have {1} health remaining.", monsterHP, playerHP);

            //if you chose a number that wasn't an option, you're dead now.  
            if (playerHP <= 0)
            {
                Console.WriteLine("You have 0 health.  You've died :(");
                Console.ReadLine();
                return;
            }

            //but if you chose a real class, you get to fight the monster
            //TODO - break this out into a function that does the fighting and returns the player's health and gold totals
            while (monsterHP > 0 && playerHP > 0)
            {
                monsterHP -= playerDmg;
                playerHP -= 3;

                Console.WriteLine("You attack it again, and it continues to fight back.");
                Console.WriteLine("You have {0} health remaining.", playerHP);

                if(playerHP <= 0)
                {
                    Console.WriteLine("You have 0 health.  You've died :(");
                    Console.ReadLine();
                    return;
                }

                if(monsterHP > 0)
                {
                    Console.WriteLine("It has {0} health remaining. You have {1} health remaining.", monsterHP, playerHP);
                }
                else if(monsterHP <= 0)
                {
                    int gold = rnd.Next(1, 6);
                    Console.WriteLine("It has 0 health remaining! You received {0} gold.", gold);
                    playerG += gold;
                } 
            }

            //basic town sequence
            //TODO - break this out into a function that returns the player's health and gold total if they choose to keep playing
            Console.WriteLine("You arrive in a town!  It costs {0} gold to rest and heal your wounds at the inn.", 2);
            playerG -= 2;
            playerHP = playerMaxHP;
            Console.WriteLine("Your health has returned to {0} and your total gold is now {1}.", playerHP, playerG);
            //TODO - add option to quit the game while in town - "This seems like a nice place to stay..."



            Console.ReadLine();

        }
    }
}
