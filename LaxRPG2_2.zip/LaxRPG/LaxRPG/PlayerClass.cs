﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaxRPG
{
    class PlayerClass
    {
        int playerClass;
        int playerHealth = 1;
        int playerMaxHealth = 1;
        int playerDamage = 1;
        int playerGold = 0;

        public PlayerClass()
        {
            Console.WriteLine("To begin, please choose your class:");
            Console.WriteLine("1. Paladin - The paladin is a balanced class that starts with 10 attack and 10 HP.");
            Console.WriteLine("2. Mage - The mage is an damage-focused class that starts with 13 attack and 7 HP.");
            Console.WriteLine("3. Ranger - The ranger is a mostly-balanced class that starts with 11 attack and 9 HP.");
            Console.WriteLine("4. Rogue - The rogue is a more damage-focused class that starts with 12 attack and 8 HP.");

            string playerClassStr = Console.ReadLine();

            //try to resolve the entered value into one of the 4 class options
            bool resolveClass = int.TryParse(playerClassStr, out playerClass);

            //if you entered something that wasn't a number...
            if (resolveClass == false)
            {
                Console.WriteLine("The value entered was not a number.");
                Console.ReadLine();
                return;
            }
        }

        public void SetHealth(int playerClass1)
        {
            switch (playerClass1)
            {
                case 1:
                    playerHealth = 10;
                    playerMaxHealth = 10;
                    break;
                case 2:
                    playerHealth = 7;
                    playerMaxHealth = 7;
                    break;
                case 3:
                    playerHealth = 9;
                    playerMaxHealth = 9;
                    break;
                case 4:
                    playerHealth = 8;
                    playerMaxHealth = 8;
                    break;
            }
        }

        public void SetDamage(int playerClass2)
        {
            switch (playerClass2)
            {
                case 1:
                    playerDamage = 10;
                    break;
                case 2:
                    playerDamage = 13;
                    break;
                case 3:
                    playerDamage = 11;
                    break;
                case 4:
                    playerDamage = 12;
                    break;
            }
        }

        public void SetPlayerGold(int gAdded)
        {
            playerGold += gAdded;
        }

        public int ApplyDamageToPlayer(int mobDmg)
        {
            playerHealth -= mobDmg;

            return playerHealth;
        }
    }
}
